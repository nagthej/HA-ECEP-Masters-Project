#!/bin/bash

echo "tensorflow for exe file"
sudp apt-get install python
python /home/for_testing/mnsit_gpu.py > /home/for_testing/output.log
