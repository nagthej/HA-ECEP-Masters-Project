import time

if __name__=="__main__":
   i= 0
   while(i<10):
      print('hello%d\n'%i)
      i = i+1
