#!/bin/bash

echo "Hello World  for exe file"
sudo apt-get install python
python /home/for_testing/hello-world.py > /home/for_testing/output.log
